<div class="item dosen">
	<div class="icon-user">
		<i class="fa fa-users fa-4x icon-mobile" aria-hidden="true"></i>	
	</div>
	<div class="data-user">		
		<h3>Dosen</h3>
		<p class="data"><?= $jumlah_dosen?></p>	
	</div>
</div>
<div class="item mahasiswa">
	<div class="icon-user">
		<i class="fa fa-user-circle fa-4x icon-mobile" aria-hidden="true"></i>	
	</div>
	<div class="data-user">		
		<h3>Mahasiswa</h3>
		<p class="data"><?= $jumlah_mhs?></p>
	</div>
</div>
<div class="item matkul">
	<div class="icon-user">
		<i class="fa fa-book fa-4x icon-mobile" aria-hidden="true"></i>	
	</div>
	<div class="data-user">		
		<h3>Mata Kuliah</h3>
		<p class="data"><?= $jumlah_matkul?></p>
	</div>
</div>
<div class="item ruangan">
	<div class="icon-user">
		<i class="fa fa-building fa-4x icon-mobile" aria-hidden="true"></i>	
	</div>
	<div class="data-user">		
		<h3>Ruangan</h3>
		<p class="data"><?= $jumlah_r?></p>	
	</div>
</div>
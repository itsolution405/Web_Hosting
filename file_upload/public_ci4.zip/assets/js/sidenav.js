function showHideNav() {
	var x = document.getElementById("page-h");		  
	if (x.style.display == "block") {
		x.style.display = "none";
	} else {
		x.style.display = "block";
	}		  
}